package com.vivek.studentinfomodule.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.mongodb.MongoException;
import com.vivek.studentinfomodule.model.Student;

@Service
public class StudentDao implements Requirements {

	
	@Autowired
	private MongoTemplate mt;
	
	@Autowired
	private ValidateStudent vs;
	
	private final static String collName=Student.class.getSimpleName();
	
	
	public void addStudent(Student student) {
		if(!validateStudent(student))throw new MongoException("validateStudent() Failed...");
		mt.insert(student,collName);
	}
	
	private boolean validateStudent(Student st) {
		if(vs.checkDuplicacy(st,mt,collName))return false;
		if(!vs.checkJY(st.getJoiningYear())) return false;
		if(!vs.checkAge(st.getAge()))return false;
		if(!vs.checkName(st.getName()))return false;
		return true;
	}

	public List<Student> getAll() {
		return mt.findAll(Student.class, collName);
	}

	public boolean deleteStudent(Student student) {
		Query query=new Query();
		query.addCriteria(Criteria.where("rollNo").is(student.getRollNo()));
		if(vs.checkDuplicacy(student,mt,collName)) {
			mt.findAndRemove(query, Student.class, collName);
		}
		else throw new MongoException("Student not Found");
		return true;
	}

	public boolean updateStudent(Student student) {
		Query query=new Query();
		query.addCriteria(Criteria.where("rollNo").is(student.getRollNo()));
		Update update=populateUpdate(student);
		if(vs.checkDuplicacy(student,mt,collName) && vs.checkJY(student.getJoiningYear()) && vs.checkAge(student.getAge()) 
				&& vs.checkName(student.getName()))
			mt.updateFirst(query, update, collName);
		else throw new MongoException("Student Validation Failed...");
		
		return true;
	}

	Update populateUpdate(Student st) {
		Update up=new Update();
		up.set("name",st.getName() );
		up.set("age", st.getAge());
		up.set("rollNo", st.getRollNo());
		up.set("standard", st.getStandard());
		up.set("joiningYear", Integer.valueOf(st.getJoiningYear()));
		return up;
	}
	
}
