package com.vivek.studentinfomodule.service;

import java.util.List;
import com.vivek.studentinfomodule.model.Student;

public interface Requirements {

	public void addStudent(Student student);
	public boolean deleteStudent(Student student);
	public boolean updateStudent(Student student);
	public List<Student> getAll();
}
