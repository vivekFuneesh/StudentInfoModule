package com.vivek.studentinfomodule.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.vivek.studentinfomodule.model.Student;
import com.vivek.studentinfomodule.service.ProcessRequest;
import com.vivek.studentinfomodule.service.Requirements;
import com.vivek.studentinfomodule.service.StudentDto;




@RestController
public class StudentController {
	
	
	@Autowired
	ProcessRequest pr;
	
	@Autowired
	private ModelAndView commonView;
	
	@RequestMapping("/")
	public ModelAndView getFirst() {
		commonView.setViewName("index.jsp");
		return commonView;
	}
	
	@RequestMapping("*")
	public ModelAndView fallBackMethod() {
		return getFirst();
	}
	
	
	@RequestMapping("/add")
	public ModelAndView add(HttpServletRequest request) {
		ModelAndView mav=new ModelAndView();
		mav.setViewName("index.jsp");
		try {
			pr.processAdd(request);
			mav.addObject("status","DONE!");
		}catch(Exception er) {
			mav.addObject("status",er.getMessage());
		}
		return mav;
	}
	
	@RequestMapping("/update")
	public ModelAndView update(HttpServletRequest request) {
		ModelAndView mav=new ModelAndView();
		mav.setViewName("index.jsp");
		try {
			pr.processUpdate(request);
			mav.addObject("status","DONE!");
		}catch(Exception er) {
			mav.addObject("status",er.getMessage());
		}
		return mav;
	}
	
	@RequestMapping("/delete")
	public ModelAndView delete(HttpServletRequest request) {
		ModelAndView mav=new ModelAndView();
		mav.setViewName("index.jsp");
		try {
			pr.processDelete(request);
			mav.addObject("status","DONE!");
		}catch(Exception er) {
			mav.addObject("status",er.getMessage());
		}
		return mav;
	}
	
	@RequestMapping("/retrieve")
	public ModelAndView retrieve() {
		ModelAndView mav=new ModelAndView();
		mav.setViewName("index.jsp");
		try {
			ArrayList<Student> list=(ArrayList)pr.processRetrieve();
			StudentDto sd=new StudentDto();
			sd.setList(list);
			mav.addObject("status",list.size()>0?sd:null);
		}catch(Exception er) {
			mav.addObject("status",er.getMessage());
		}
		return mav;
	}
	
}
