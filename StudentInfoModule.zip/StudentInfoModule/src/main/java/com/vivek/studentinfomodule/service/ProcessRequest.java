package com.vivek.studentinfomodule.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vivek.studentinfomodule.model.Student;

@Service
public class ProcessRequest {

	@Autowired
	Requirements req;
	
	public void processAdd(HttpServletRequest request) {
		Student st=getStudent(request);
		req.addStudent(st);
	}

	public void processUpdate(HttpServletRequest request) {
		Student st=getStudent(request);
		req.updateStudent(st);
	}

	/**
	 * Deletion by rollNumber only... no need for all data.
	 */
	public void processDelete(HttpServletRequest request) {
		Student st=new Student();
		st.setRollNo(request.getParameter("rollNo"));
		req.deleteStudent(st);
	}

	public List<Student> processRetrieve() {
		return req.getAll();
	}

	private Student getStudent(HttpServletRequest request) {
		Student st=new Student();
		st.setAge(request.getParameter("age"));
		st.setJoiningYear(Integer.valueOf(request.getParameter("joiningYear")));
		st.setName(request.getParameter("name"));
		st.setRollNo(request.getParameter("rollNo"));
		st.setStandard(request.getParameter("standard"));
		return st;
	}
	
}
