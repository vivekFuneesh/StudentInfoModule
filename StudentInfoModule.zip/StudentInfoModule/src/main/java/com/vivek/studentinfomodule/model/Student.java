package com.vivek.studentinfomodule.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Student {
	
	@Id
	private String _id;
	
	@NotBlank
	@Indexed(unique=true)
	private String rollNo;
	
	@NotBlank
	private String name;
	
	@NotBlank
	private String age;
	
	@NotBlank
	private String standard;
	
	@NotNull
	private Integer joiningYear;


	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public Integer getJoiningYear() {
		return joiningYear;
	}

	public void setJoiningYear(Integer joiningYear) {
		this.joiningYear = joiningYear;
	}
	
	
}
