package com.vivek.studentinfomodule.service;

import java.util.Iterator;
import java.util.List;

import com.vivek.studentinfomodule.model.Student;

public class StudentDto {

	private List<Student> list;
	
	public void setList(List<Student> l) {
		list=l;
	}
	public List<Student> getList(){
		return list;
	}
	
	/**
	 * Modifying output to make it pretty on html..
	 */
	@Override
	public String toString() {
		if(list==null || list.size()==0) return "";
		StringBuffer sb=new StringBuffer();
		Iterator<Student> itr=list.iterator();
		
		while(itr.hasNext()) {
			Student tmp=itr.next();
			sb.append("Name: "+tmp.getName()+" ,");
			sb.append("RollNo: "+tmp.getRollNo()+" ,");
			sb.append("Age: "+tmp.getAge()+" ,");
			sb.append("Standard: "+tmp.getStandard()+" ,");
			sb.append("JoiningYear: "+tmp.getJoiningYear());
			sb.append("<br>");
		}
		return sb.toString();
	}
}
