package com.vivek.studentinfomodule.service;

import java.util.Date;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Component;

import com.vivek.studentinfomodule.model.Student;

@Component
public class ValidateStudent {

	boolean checkName(String name) {
		if(name==null || name.trim().length()==0)return false;
		return true;
	}
	
	boolean checkAge(String age) {
		int a=Integer.valueOf(age);
		if(a<=0 || a>=100)return false;
		return true;
	}
	
	boolean checkStandard(String stnd) {
		//can be different for roman or number system.. 
		return true;
	}
	
	boolean checkJY(int date) {
		if(date<2000 || date>new Date().getYear()+1900)return false;
		return true;
	}
	
	boolean checkDuplicacy(Student st,MongoTemplate mt, String collName) {
		Query query=new Query();
		query.addCriteria(Criteria.where("rollNo").is(st.getRollNo()));
		return (mt.find(query, Student.class, collName).size())>0?true:false;
	}

	
}
