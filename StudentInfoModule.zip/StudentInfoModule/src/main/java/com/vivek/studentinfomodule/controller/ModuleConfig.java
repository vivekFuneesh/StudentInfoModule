package com.vivek.studentinfomodule.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.mongodb.MongoClient;
import com.vivek.studentinfomodule.service.URIInitializer;

@Configuration
@ComponentScan({"com.vivek.studentinfomodule.controller","com.vivek.studentinfomodule.service"})
public class ModuleConfig {

	
	@Autowired
	private URIInitializer uriI;
	
	@Bean
	MongoTemplate getMT() {
		return new MongoTemplate(getMC(),uriI.getDbName());
	}
	
	@Bean
	MongoClient getMC() {
		return new MongoClient(uriI.getHost(),uriI.getPort());
	}
	
	@Bean
	ModelAndView getModelAndView() {
		return new ModelAndView();
	}
}
